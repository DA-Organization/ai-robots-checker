"use client";

import { useState, useCallback } from "react";
import {
  Search,
  Globe,
  AlertTriangle,
  Loader2,
  ChevronRight,
  FileText,
  Shield,
  Zap,
  RotateCcw,
} from "lucide-react";
import { fetchRobotsTxt, buildAnalysis } from "@/lib/robotsParser";
import type { RobotsAnalysis } from "@/types";
import AuthModal from "./AuthModal";
import ProtectionScore from "./ProtectionScore";
import BotStatusGrid from "./BotStatusGrid";
import CodeGenerator from "./CodeGenerator";
import { useAuth } from "@/lib/authContext";

type Tab = "analyzer" | "generator";

const SAMPLE_ROBOTS = `User-agent: *
Allow: /

User-agent: GPTBot
Disallow: /

User-agent: ClaudeBot
Disallow: /`;

export default function AnalyzerPanel() {
  const { user } = useAuth();

  const [url, setUrl] = useState("");
  const [pastedContent, setPastedContent] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [showCorsBox, setShowCorsBox] = useState(false);
  const [analysis, setAnalysis] = useState<RobotsAnalysis | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [pendingAnalysis, setPendingAnalysis] = useState(false);
  const [activeTab, setActiveTab] = useState<Tab>("analyzer");
  const [showRawContent, setShowRawContent] = useState(false);

  const runAnalysis = useCallback(
    async (forceUrl?: string, forcePasted?: string) => {
      const targetUrl = forceUrl ?? url;
      const targetPasted = forcePasted ?? pastedContent;

      setError(null);
      setIsLoading(true);
      setShowCorsBox(false);

      try {
        let rawContent = "";
        let fetchMethod: "direct" | "cors-blocked" | "pasted" = "direct";
        let domain = targetUrl;

        if (targetPasted.trim()) {
          // Use pasted content
          rawContent = targetPasted.trim();
          fetchMethod = "pasted";
          domain = targetUrl.trim() || "your-website.com";
        } else if (targetUrl.trim()) {
          // Try fetching from URL
          const result = await fetchRobotsTxt(targetUrl.trim());

          if (result.method === "cors-blocked" || !result.content) {
            setShowCorsBox(true);
            setIsLoading(false);
            return;
          }

          rawContent = result.content;
          fetchMethod = result.method;

          // Extract domain
          try {
            const urlObj = new URL(
              targetUrl.startsWith("http") ? targetUrl : "https://" + targetUrl
            );
            domain = urlObj.hostname;
          } catch {
            domain = targetUrl;
          }
        } else {
          setError("Please enter a website URL or paste your robots.txt content.");
          setIsLoading(false);
          return;
        }

        const result = buildAnalysis(domain, rawContent, fetchMethod);
        setAnalysis(result);
      } catch {
        setError("Analysis failed. Please check the URL and try again.");
      } finally {
        setIsLoading(false);
      }
    },
    [url, pastedContent]
  );

  const handleAnalyzeClick = useCallback(() => {
    if (!url.trim() && !pastedContent.trim()) {
      setError("Please enter a website URL or paste your robots.txt content.");
      return;
    }

    if (!user) {
      setPendingAnalysis(true);
      setShowAuthModal(true);
    } else {
      runAnalysis();
    }
  }, [url, pastedContent, user, runAnalysis]);

  const handleAuthSuccess = useCallback(() => {
    setShowAuthModal(false);
    if (pendingAnalysis) {
      setPendingAnalysis(false);
      runAnalysis();
    }
  }, [pendingAnalysis, runAnalysis]);

  const handleTrySample = useCallback(() => {
    setPastedContent(SAMPLE_ROBOTS);
    setUrl("example.com");
  }, []);

  const handleReset = useCallback(() => {
    setAnalysis(null);
    setError(null);
    setShowCorsBox(false);
    setPastedContent("");
    setUrl("");
    setShowRawContent(false);
  }, []);

  const handlePastedAnalyze = useCallback(() => {
    if (!pastedContent.trim()) {
      setError("Please paste your robots.txt content.");
      return;
    }
    runAnalysis();
  }, [pastedContent, runAnalysis]);

  return (
    <>
      <AuthModal
        isOpen={showAuthModal}
        onClose={() => {
          setShowAuthModal(false);
          setPendingAnalysis(false);
        }}
        onSuccess={handleAuthSuccess}
      />

      <div className="space-y-6">
        {/* Tab Switcher */}
        <div className="flex gap-1 bg-[#080f1e] border border-cyan-500/10 rounded-xl p-1">
          {(["analyzer", "generator"] as Tab[]).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex-1 flex items-center justify-center gap-2 rounded-lg py-2.5 px-4 text-sm font-semibold transition-all duration-200 cursor-pointer capitalize ${
                activeTab === tab
                  ? "bg-gradient-to-r from-cyan-500/20 to-blue-500/20 border border-cyan-500/30 text-white shadow-lg shadow-cyan-500/5"
                  : "text-slate-400 hover:text-slate-300"
              }`}
            >
              {tab === "analyzer" ? (
                <Shield className="w-4 h-4" />
              ) : (
                <FileText className="w-4 h-4" />
              )}
              {tab === "analyzer" ? "Analyze Website" : "Code Generator"}
            </button>
          ))}
        </div>

        {activeTab === "analyzer" ? (
          <>
            {!analysis ? (
              /* Input Panel */
              <div className="bg-[#0d1f3d] border border-cyan-500/10 rounded-2xl p-6">
                <div className="flex items-center gap-2 mb-6">
                  <div className="w-10 h-10 bg-cyan-500/10 border border-cyan-500/20 rounded-xl flex items-center justify-center">
                    <Zap className="w-5 h-5 text-cyan-400" />
                  </div>
                  <div>
                    <h2 className="text-white font-bold text-xl">
                      AI Crawler Analyzer
                    </h2>
                    <p className="text-slate-400 text-sm">
                      Instantly audit which AI bots can access your website
                    </p>
                  </div>
                </div>

                {/* URL Input */}
                <div className="space-y-4">
                  <div>
                    <label className="text-slate-300 text-sm font-medium mb-2 block">
                      Website URL
                    </label>
                    <div className="relative">
                      <Globe className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 pointer-events-none" />
                      <input
                        type="text"
                        value={url}
                        onChange={(e) => {
                          setUrl(e.target.value);
                          setError(null);
                        }}
                        onKeyDown={(e) =>
                          e.key === "Enter" && handleAnalyzeClick()
                        }
                        placeholder="e.g. yourwebsite.com or https://yourwebsite.com"
                        className="w-full bg-[#080f1e] border border-slate-700 focus:border-cyan-500 text-white placeholder-slate-500 rounded-xl py-4 pl-12 pr-4 text-sm outline-none transition-all duration-200"
                      />
                    </div>
                  </div>

                  {/* Paste area */}
                  <div>
                    <label className="text-slate-300 text-sm font-medium mb-2 block">
                      Or paste robots.txt content directly{" "}
                      <span className="text-slate-500 font-normal text-xs">
                        (optional)
                      </span>
                    </label>
                    <textarea
                      value={pastedContent}
                      onChange={(e) => {
                        setPastedContent(e.target.value);
                        setError(null);
                      }}
                      placeholder="Paste your robots.txt content here for instant analysis…"
                      rows={5}
                      className="w-full bg-[#080f1e] border border-slate-700 focus:border-cyan-500 text-white placeholder-slate-500 rounded-xl py-3 px-4 text-sm font-mono outline-none transition-all duration-200 resize-none"
                    />
                  </div>

                  {error && (
                    <div className="flex items-start gap-2.5 bg-red-500/10 border border-red-500/20 rounded-xl p-3.5">
                      <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
                      <p className="text-red-400 text-sm">{error}</p>
                    </div>
                  )}

                  {/* CTA Buttons */}
                  <div className="flex flex-col sm:flex-row gap-3">
                    <button
                      onClick={handleAnalyzeClick}
                      disabled={isLoading}
                      className="flex-1 flex items-center justify-center gap-2.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold rounded-xl py-4 px-6 transition-all duration-200 shadow-lg hover:shadow-cyan-500/20 disabled:opacity-50 disabled:cursor-not-allowed text-sm cursor-pointer"
                    >
                      {isLoading ? (
                        <>
                          <Loader2 className="w-5 h-5 animate-spin" />
                          Analyzing…
                        </>
                      ) : (
                        <>
                          <Search className="w-5 h-5" />
                          Analyze Website
                          <ChevronRight className="w-4 h-4" />
                        </>
                      )}
                    </button>

                    <button
                      onClick={handleTrySample}
                      className="flex items-center justify-center gap-2 bg-[#080f1e] border border-slate-700 hover:border-slate-500 text-slate-300 hover:text-white font-medium rounded-xl py-4 px-5 transition-all duration-200 text-sm cursor-pointer"
                    >
                      <FileText className="w-4 h-4" />
                      Try Sample
                    </button>
                  </div>

                  {/* Gate notice for unauthenticated users */}
                  {!user && (
                    <div className="flex items-center gap-2 bg-amber-500/5 border border-amber-500/15 rounded-xl px-4 py-3">
                      <Shield className="w-4 h-4 text-amber-400 flex-shrink-0" />
                      <p className="text-slate-400 text-xs">
                        <span className="text-amber-400 font-semibold">
                          Free account required
                        </span>{" "}
                        to view full analysis results — takes only 10 seconds.
                      </p>
                    </div>
                  )}
                </div>
              </div>
            ) : (
              /* Results Panel */
              <div className="space-y-6">
                {/* Result header */}
                <div className="bg-[#0d1f3d] border border-cyan-500/10 rounded-2xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <Globe className="w-4 h-4 text-cyan-400" />
                      <span className="text-white font-bold text-lg">
                        {analysis.domain}
                      </span>
                      <span
                        className={`text-[10px] uppercase tracking-widest font-mono px-2 py-0.5 rounded-full border ${
                          analysis.fetchMethod === "pasted"
                            ? "bg-blue-500/10 text-blue-400 border-blue-500/20"
                            : analysis.fetchMethod === "direct"
                            ? "bg-green-500/10 text-green-400 border-green-500/20"
                            : "bg-amber-500/10 text-amber-400 border-amber-500/20"
                        }`}
                      >
                        {analysis.fetchMethod === "pasted"
                          ? "📋 Pasted"
                          : analysis.fetchMethod === "direct"
                          ? "🌐 Fetched"
                          : "⚠️ Manual"}
                      </span>
                    </div>
                    <p className="text-slate-500 text-xs">
                      Analyzed at{" "}
                      {analysis.analyzedAt.toLocaleTimeString()} ·{" "}
                      {analysis.bots.length} AI agents audited
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setShowRawContent(!showRawContent)}
                      className="flex items-center gap-1.5 bg-[#080f1e] border border-slate-700 hover:border-slate-500 text-slate-400 hover:text-white rounded-lg px-3 py-2 text-xs transition-all cursor-pointer"
                    >
                      <FileText className="w-3.5 h-3.5" />
                      Raw Content
                    </button>
                    <button
                      onClick={handleReset}
                      className="flex items-center gap-1.5 bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 text-red-400 rounded-lg px-3 py-2 text-xs transition-all cursor-pointer"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      New Analysis
                    </button>
                  </div>
                </div>

                {/* Raw content toggle */}
                {showRawContent && (
                  <div className="bg-[#080f1e] border border-slate-700 rounded-xl p-4 max-h-48 overflow-y-auto">
                    <pre className="text-slate-400 text-xs font-mono whitespace-pre-wrap leading-relaxed">
                      {analysis.rawContent ||
                        "No robots.txt content was found."}
                    </pre>
                  </div>
                )}

                {/* Protection Score */}
                <ProtectionScore score={analysis.protectionScore} />

                {/* Bot Status Grid */}
                <BotStatusGrid bots={analysis.bots} />

                {/* Switch to generator CTA */}
                <div className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border border-cyan-500/20 rounded-2xl p-5 flex flex-col sm:flex-row items-center gap-4">
                  <div className="flex-1">
                    <h4 className="text-white font-bold mb-1">
                      🛡️ Ready to protect your website?
                    </h4>
                    <p className="text-slate-400 text-sm">
                      Use our Code Generator to block all AI crawlers with a
                      single optimized robots.txt file.
                    </p>
                  </div>
                  <button
                    onClick={() => setActiveTab("generator")}
                    className="flex items-center gap-2 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold rounded-xl py-3 px-5 text-sm transition-all whitespace-nowrap cursor-pointer shadow-lg hover:shadow-cyan-500/20"
                  >
                    <FileText className="w-4 h-4" />
                    Generate Fix
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {/* CORS Fallback Box */}
            {showCorsBox && !analysis && (
              <div className="bg-[#0d1f3d] border-2 border-amber-500/30 rounded-2xl p-6">
                <div className="flex items-start gap-3 mb-4">
                  <div className="w-10 h-10 bg-amber-500/10 border border-amber-500/20 rounded-xl flex items-center justify-center flex-shrink-0">
                    <AlertTriangle className="w-5 h-5 text-amber-400" />
                  </div>
                  <div>
                    <h3 className="text-amber-400 font-bold text-base mb-1">
                      CORS Protection Active
                    </h3>
                    <p className="text-slate-400 text-sm leading-relaxed">
                      Your website has CORS headers that prevent direct browser
                      fetch requests. This is actually a good security sign! To
                      continue your AI analysis, please manually copy and paste
                      your robots.txt content below.
                    </p>
                  </div>
                </div>

                <div className="bg-[#080f1e] border border-amber-500/20 rounded-xl p-4 mb-4">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-2 h-2 bg-amber-400 rounded-full" />
                    <span className="text-amber-400 text-xs font-semibold uppercase tracking-wide">
                      How to get your robots.txt content
                    </span>
                  </div>
                  <ol className="text-slate-400 text-xs space-y-1.5 list-decimal list-inside leading-relaxed">
                    <li>
                      Open a new tab and visit:{" "}
                      <code className="text-cyan-400 bg-cyan-500/10 px-1 rounded">
                        {url.startsWith("http")
                          ? new URL(url).origin
                          : `https://${url}`}
                        /robots.txt
                      </code>
                    </li>
                    <li>Select all text on that page (Ctrl+A / Cmd+A)</li>
                    <li>Copy it (Ctrl+C / Cmd+C)</li>
                    <li>Paste it in the box below</li>
                  </ol>
                </div>

                <textarea
                  value={pastedContent}
                  onChange={(e) => setPastedContent(e.target.value)}
                  placeholder="Paste your robots.txt content here for instant AI analysis…"
                  rows={8}
                  className="w-full bg-[#080f1e] border border-amber-500/20 focus:border-amber-500/50 text-white placeholder-slate-600 rounded-xl py-3 px-4 text-sm font-mono outline-none transition-all duration-200 resize-none mb-4"
                />

                <div className="flex gap-3">
                  <button
                    onClick={handlePastedAnalyze}
                    disabled={!pastedContent.trim() || isLoading}
                    className="flex-1 flex items-center justify-center gap-2 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-white font-bold rounded-xl py-3.5 px-5 text-sm transition-all disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
                  >
                    {isLoading ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Search className="w-4 h-4" />
                    )}
                    Analyze Pasted Content
                  </button>
                  <button
                    onClick={() => {
                      setShowCorsBox(false);
                      setUrl("");
                    }}
                    className="bg-[#080f1e] border border-slate-700 hover:border-slate-500 text-slate-400 hover:text-white rounded-xl px-4 transition-all cursor-pointer"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}
          </>
        ) : (
          /* Code Generator Tab */
          <CodeGenerator />
        )}
      </div>
    </>
  );
}
