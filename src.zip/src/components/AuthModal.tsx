"use client";

import { useState, useCallback } from "react";
import { X, Mail, Shield, Zap, Lock, CheckCircle } from "lucide-react";
import { useAuth } from "@/lib/authContext";

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export default function AuthModal({ isOpen, onClose, onSuccess }: AuthModalProps) {
  const { signInWithGoogle, signInWithEmail, isLoading } = useAuth();
  const [email, setEmail] = useState("");
  const [emailError, setEmailError] = useState("");
  const [emailSent, setEmailSent] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [emailLoading, setEmailLoading] = useState(false);

  const handleGoogleSignIn = useCallback(async () => {
    setGoogleLoading(true);
    await signInWithGoogle();
    setGoogleLoading(false);
    onSuccess();
  }, [signInWithGoogle, onSuccess]);

  const handleEmailSignIn = useCallback(async () => {
    setEmailError("");
    const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
    if (!emailRegex.test(email)) {
      setEmailError("Please enter a valid email address (e.g., you@example.com)");
      return;
    }

    setEmailLoading(true);
    const result = await signInWithEmail(email);
    setEmailLoading(false);

    if (result.success) {
      setEmailSent(true);
      setTimeout(() => {
        onSuccess();
      }, 1500);
    } else {
      setEmailError(result.error || "Something went wrong. Please try again.");
    }
  }, [email, signInWithEmail, onSuccess]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/80 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Modal */}
      <div className="relative w-full max-w-md bg-[#0a1628] border border-cyan-500/30 rounded-2xl shadow-2xl shadow-cyan-500/10 overflow-hidden">
        {/* Gradient top bar */}
        <div className="h-1 w-full bg-gradient-to-r from-cyan-500 via-blue-500 to-cyan-400" />

        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white transition-colors cursor-pointer z-10"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="p-8">
          {/* Icon + Header */}
          <div className="flex flex-col items-center text-center mb-8">
            <div className="w-16 h-16 bg-cyan-500/10 border border-cyan-500/30 rounded-2xl flex items-center justify-center mb-4">
              <Lock className="w-8 h-8 text-cyan-400" />
            </div>
            <h2 className="text-2xl font-bold text-white mb-2">
              Unlock Your Analysis
            </h2>
            <p className="text-slate-400 text-sm leading-relaxed">
              Create your{" "}
              <span className="text-cyan-400 font-semibold">free account</span>{" "}
              to instantly view your AI protection score, bot audit results, and
              personalized recommendations.
            </p>
          </div>

          {/* Benefits */}
          <div className="grid grid-cols-3 gap-3 mb-8">
            {[
              { icon: Shield, label: "AI Score", desc: "Protection rating" },
              { icon: Zap, label: "Bot Audit", desc: "7 AI crawlers" },
              { icon: CheckCircle, label: "Code Gen", desc: "One-click fix" },
            ].map(({ icon: Icon, label, desc }) => (
              <div
                key={label}
                className="bg-[#0d1f3d] border border-cyan-500/10 rounded-xl p-3 text-center"
              >
                <Icon className="w-5 h-5 text-cyan-400 mx-auto mb-1.5" />
                <div className="text-white text-xs font-semibold">{label}</div>
                <div className="text-slate-500 text-[10px]">{desc}</div>
              </div>
            ))}
          </div>

          {emailSent ? (
            <div className="flex flex-col items-center gap-3 py-4">
              <div className="w-14 h-14 bg-green-500/10 border border-green-500/30 rounded-full flex items-center justify-center">
                <CheckCircle className="w-7 h-7 text-green-400" />
              </div>
              <p className="text-green-400 font-semibold text-center">
                Signed in successfully!
              </p>
              <p className="text-slate-400 text-sm text-center">
                Loading your analysis results…
              </p>
            </div>
          ) : (
            <>
              {/* Google Sign In */}
              <button
                onClick={handleGoogleSignIn}
                disabled={googleLoading || emailLoading || isLoading}
                className="w-full flex items-center justify-center gap-3 bg-white hover:bg-slate-100 text-slate-900 font-semibold rounded-xl py-3.5 px-6 mb-4 transition-all duration-200 shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
              >
                {googleLoading ? (
                  <div className="w-5 h-5 border-2 border-slate-400 border-t-slate-700 rounded-full animate-spin" />
                ) : (
                  <svg viewBox="0 0 24 24" className="w-5 h-5" aria-hidden="true">
                    <path
                      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                      fill="#4285F4"
                    />
                    <path
                      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                      fill="#34A853"
                    />
                    <path
                      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                      fill="#FBBC05"
                    />
                    <path
                      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                      fill="#EA4335"
                    />
                  </svg>
                )}
                {googleLoading ? "Connecting…" : "One-Click Login with Google"}
              </button>

              {/* Divider */}
              <div className="flex items-center gap-3 mb-4">
                <div className="flex-1 h-px bg-slate-700" />
                <span className="text-slate-500 text-xs font-medium">or</span>
                <div className="flex-1 h-px bg-slate-700" />
              </div>

              {/* Email Sign In */}
              <div className="space-y-3">
                <div className="relative">
                  <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => {
                      setEmail(e.target.value);
                      setEmailError("");
                    }}
                    onKeyDown={(e) => e.key === "Enter" && handleEmailSignIn()}
                    placeholder="Enter your email address"
                    className="w-full bg-[#0d1f3d] border border-slate-600 focus:border-cyan-500 text-white placeholder-slate-500 rounded-xl py-3.5 pl-10 pr-4 text-sm outline-none transition-all duration-200"
                  />
                </div>
                {emailError && (
                  <p className="text-red-400 text-xs flex items-center gap-1.5">
                    <span className="w-4 h-4 rounded-full bg-red-500/20 flex items-center justify-center text-[10px] flex-shrink-0">!</span>
                    {emailError}
                  </p>
                )}
                <button
                  onClick={handleEmailSignIn}
                  disabled={googleLoading || emailLoading || isLoading}
                  className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-semibold rounded-xl py-3.5 px-6 transition-all duration-200 shadow-lg hover:shadow-cyan-500/20 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
                >
                  {emailLoading ? (
                    <div className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                  ) : (
                    <Mail className="w-4 h-4" />
                  )}
                  {emailLoading ? "Sending…" : "Continue with Email"}
                </button>
              </div>
            </>
          )}

          {/* Footer note */}
          <p className="text-center text-slate-600 text-[11px] mt-6">
            100% free. No credit card. By signing in you agree to our{" "}
            <span className="text-cyan-500/70 cursor-pointer hover:text-cyan-400 transition-colors">
              Terms
            </span>{" "}
            &amp;{" "}
            <span className="text-cyan-500/70 cursor-pointer hover:text-cyan-400 transition-colors">
              Privacy Policy
            </span>.
          </p>
        </div>
      </div>
    </div>
  );
}
